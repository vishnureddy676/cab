package com.vishnu.Rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;


import com.vishnu.dto.Extract;
import com.vishnu.dto.LoginDTO;
import com.vishnu.dto.User;

public class StudentRowMapper implements RowMapper<Extract>{
	

	@Override
	public Extract mapRow(ResultSet rs, int rowNum) throws SQLException {
		Extract extract= new Extract();
		extract.setUname(rs.getString("name"));	
		extract.setPsw(rs.getString("password"));	
		extract.setCountry(rs.getString("country"));
		extract.setMobile(rs.getLong("mobile"));
		
		
		System.out.println(extract);
		
		
		return extract;
	}
	

}
