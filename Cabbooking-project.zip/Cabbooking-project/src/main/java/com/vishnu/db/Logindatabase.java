package com.vishnu.db;


import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.vishnu.Rowmapper.StudentRowMapper;
import com.vishnu.dto.Extract;



public class Logindatabase implements Logindb {
	 JdbcTemplate jdbcTemplate  = new JdbcTemplate(getDataSource());

	@Override
	public void Insert(Object[] vis) {
	 
		
		String sql= "INSERT INTO Cab VALUES(?,?,?,?)";
		
			
		
			
		int abc=jdbcTemplate.update(sql,vis);
		System.out.println(abc);
		
		

		}
		
		
		public DataSource getDataSource() {
			String url ="jdbc:oracle:thin:@localhost:1521:xe";
			String username="system";
			String password="ammananna@7";
			String classname="oracle.jdbc.driver.OracleDriver";
			
			DriverManagerDataSource dataSource =new DriverManagerDataSource();
			dataSource.setUsername(username);
			dataSource.setPassword(password);
			dataSource.setUrl(url);
			dataSource.setDriverClassName(classname);
			
			
			return dataSource;
		}


		@Override
		public int Login(String s1, String s2) {
			
			int x;
			
		String	sql ="SELECT * FROM Cab WHERE name=? AND password=?";
	try {
		Extract extracts =jdbcTemplate.queryForObject(sql ,new BeanPropertyRowMapper<Extract>(Extract.class),s1,s2);
		
		x=0;
		
	}
	catch (DataAccessException e) {
		
		
	x=1;
		
	}
	   return x;
		
		
		
			
		}


		@Override
		public void Feedback(Object[] vis) {
			String sql= "INSERT INTO Feedbackcab VALUES(?,?,?)";
			
			
			
			
			int abc=jdbcTemplate.update(sql,vis);
			System.out.println(abc);
			
			
			
		}


		@Override
		public void Book(Object[] vis) {
			
			String sql= "INSERT INTO Book VALUES(?,?,?,?)";
			
			
			
			
			int abc=jdbcTemplate.update(sql,vis);
			System.out.println(abc);
			
			
		}


		
		
		

 
	}


