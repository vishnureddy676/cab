package com.vishnu.db;

import java.util.List;

import com.vishnu.dto.Extract;

public interface Logindb {
	
	public void Insert(Object[]  vis);
	public int Login(String s1, String s2);
	public void Feedback(Object[]  vis);
	public void Book(Object[]  vis);

}
